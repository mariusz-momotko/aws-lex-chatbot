'use strict';

/**
 * Utility functions of a general purpose
 */
 
module.exports = {
 // checking if a given object is empty
 isEmpty: function(obj) {
    for(var key in obj) {
        if(obj.hasOwnProperty(key))
            return false;
    }
    return true;
 }
}