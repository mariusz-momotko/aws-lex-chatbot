'use strict';

// global modules
const util = require('util');

// utility modules
const jsonUtils = require('./jsonUtils.js');
const responseUtils = require('./lexResponseUtils');

// messages
const ERR_STATIONS_SAME = 
 "The train station where you start your trip is the same as the station " +
 "when you end your trip: %s." + 
 "Please change the station when you end your trip.";

// --------------- Main handler -----------------------
// It is base on non-async call as described {@link https://docs.aws.amazon.com/lex/latest/dg/gs2-prepare.html}
exports.handler = (event, context, callback) => {
    try {
        if (event.bot.name != 'OrderTicket') {
            callback('Invalid Bot Name');
        }
        processRequest(event, (response) => callback(null, response));
    } catch (err) {
        callback(err);
    }
};

// Validate the request 
function processRequest(request, callback) {
    
    // validate that to & from stations are not the same
    if (!validateStations(request, callback)) return;
   
    // if all validation passed - continue processing     
    callback(responseUtils.delegate(request.sessionAttributes, request.currentIntent.slots));
}  

// Validate that from and to stations are not the same.
// In case of an error - callback is invoked.
function validateStations(request, callback) {
  var validation = false;
  const fromStation = request.currentIntent.slots.fromStation;
  const toStation = request.currentIntent.slots.toStation;
    if (!jsonUtils.isEmpty(fromStation) && !jsonUtils.isEmpty(toStation) && fromStation.toString() == toStation.toString()){
        // the same station - must provide again toStation slot
        const originalFromStation = request.currentIntent.slotDetails.fromStation.originalValue;
        const message = util.format(ERR_STATIONS_SAME, originalFromStation);
        callback(responseUtils.elicitSlotWithMessage(message, request.sessionAttributes, request.currentIntent.name, request.currentIntent.slots, "toStation")); 
    } else {
        validation = true;
    }
    return validation;
}
