'use strict';

/**
 * Utility functions that helps preparing responses to Lex
 * during chatbot conversation.
 * For a list of Lex commands
 * see {@link https://docs.aws.amazon.com/lex/latest/dg/lambda-input-response-format.html}.
 */ 

module.exports = {
 // Prepares a Lex response for Delegate command.
 delegate : function(sessionAttributes, slots) {
    return {
        sessionAttributes,
        dialogAction: {
            type: 'Delegate',
            slots,
        },
    };
 },

 // Prepares a Lex response for ElicitSlot command.
 elicitSlot: function(sessionAttributes, intentName, slots, slotToElicit) {
    return {
        sessionAttributes,
        dialogAction: {
            type: 'ElicitSlot',
            intentName,
            slots,
            slotToElicit
        },
    };
 },

 // Prepares ElicitSlot command with a response message
 elicitSlotWithMessage:  function(messageContent, sessionAttributes, intentName, slots, slotToElicit) {
    return {
        sessionAttributes,
        dialogAction: {
            type: 'ElicitSlot',
            intentName,
            slots,
            slotToElicit,
            message: { contentType: 'PlainText', content: messageContent }
        }
    };
 }
}