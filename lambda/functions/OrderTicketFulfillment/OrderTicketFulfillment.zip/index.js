'use strict';

// global modules
const util = require('util');

// utility modules
const responseUtils = require('./lexResponseUtils');

// pattern to generate url
const URL_PATTERN = "https://bilety.skm.pkp.pl/pl/search/%s/%s/%s-%s-%s_%s";
// final message
const FINAL_TEXT_MSG = "Thank you. To order a SKM ticket please use this link: %s .";
const FINAL_VOICE_MSG = "<speak>Thank you. To order a SKM ticket please use the provided link</speak>: %s .";

// --------------- Main handler -----------------------
// It is base on non-async call as described {@link https://docs.aws.amazon.com/lex/latest/dg/gs2-prepare.html}
exports.handler = (event, context, callback) => {
    try {
        if (event.bot.name != 'OrderTicket') {
            callback('Invalid Bot Name');
        }
        processRequest(event, (response) => callback(null, response));
    } catch (err) {
        callback(err);
    }
};

// format the final bot response
function processRequest(request, callback) {
    
    // generate url
    var message;
    if (request.outputDialogMode == "Voice") {
       const message = util.format(FINAL_VOICE_MSG, generateUrl(request, callback));
       // complete conversation with the proper final message
       callback(responseUtils.closeWithVoiceMessage(request.sessionAttributes, message));
    } else { 
        const message = util.format(FINAL_TEXT_MSG, generateUrl(request, callback));
        // complete conversation with the proper final message
        callback(responseUtils.closeWithTextMessage(request.sessionAttributes, message));
    }
}  

// Validate that from and to stations are not the same.
// In case of an error - callback is invoked.
function generateUrl(request, callback) {
  // get slot values
  const fromStation = request.currentIntent.slots.fromStation;
  const toStation = request.currentIntent.slots.toStation;
  const dateOfTravelParts = request.currentIntent.slots.dateOfTravel.split("-");
  const timeOfTravel = request.currentIntent.slots.timeOfTravel;
  
  // generate url
  return util.format(URL_PATTERN, 
   fromStation,
   toStation,
   dateOfTravelParts[2], // day
   dateOfTravelParts[1], // month
   dateOfTravelParts[0], // year
   timeOfTravel
  );
}