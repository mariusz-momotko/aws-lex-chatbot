'use strict';

/**
 * Utility functions that helps preparing responses to Lex
 * during chatbot conversation.
 * For a list of Lex commands
 * see {@link https://docs.aws.amazon.com/lex/latest/dg/lambda-input-response-format.html}.
 */ 

module.exports = {
// close the conversation with the bot 
 closeWithVoiceMessage: function(sessionAttributes, message) {
    return {
        sessionAttributes,
        dialogAction: {
            "type": 'Close',
            "fulfillmentState": "Fulfilled",
            "message" : {
                "contentType": 'SSML', 
                "content": message
            },
        },
    };
 },
 closeWithTextMessage: function(sessionAttributes, message,) {
    return {
        sessionAttributes,
        dialogAction: {
            "type": 'Close',
            "fulfillmentState": "Fulfilled",
            "message" : {
                "contentType": 'PlainText', 
                "content": message
            },
        },
    };
 }
}